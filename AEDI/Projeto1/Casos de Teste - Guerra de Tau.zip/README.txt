Arquivo zip gerado em: 21/06/2018 18:50:06 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: 3a. chamada da Guerra de Tau