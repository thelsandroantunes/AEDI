Arquivo zip gerado em: 27/06/2018 12:58:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: PP4 - Alocação Dinâmica